package com.kj.cherryengineering20.employees;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.kj.cherryengineering20.R;

public class AddEmployeeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_employee);
    }


}