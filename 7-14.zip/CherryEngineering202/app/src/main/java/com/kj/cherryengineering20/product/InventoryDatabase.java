package com.kj.cherryengineering20.product;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

public class InventoryDatabase {

    private Context mContext;
    private final String FILE_NAME;

    public InventoryDatabase(Context context) {
        mContext = context;
        FILE_NAME = "inventory.txt";
    }

    public void updateInventory(int selection) {
        HashMap<String, Double> map = getInventoryAsHashmap();
        double newValue = 0;
        for (String key : map.keySet()) {
            newValue = map.get(key) - (selection * 16);
            if (newValue < 0) {
                newValue = 0;
            }
            map.replace(key, newValue);
        }

        String content = map.toString();
        try (FileOutputStream fos = mContext.openFileOutput(FILE_NAME, MODE_PRIVATE)) {
            fos.write(content.getBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Toast.makeText(mContext, "Saved to " + mContext.getFilesDir() + "/inventory.txt", Toast.LENGTH_LONG).show();
    }

    public HashMap<String, Double> getInventoryAsHashmap() {
        FileInputStream fis = null;
        HashMap<String, Double> map = new HashMap<>();

        try {
            fis = mContext.openFileInput("inventory.txt");
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            String text;

            while ((text = br.readLine()) != null) {
                String[] itemLine = text.split(",");
                for (int i = 0; i < itemLine.length; i++) {
                    String[] item = itemLine[i].split("=");
                    item[0] = item[0].replaceAll("[\\[\\](){}]", "");
                    item[1] = item[1].replaceAll("[\\[\\](){}]", "");
                    String itemName = item[0];
                    double quantity = Double.parseDouble(item[1]);
                    map.put(itemName, quantity);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return map;
    }
}
