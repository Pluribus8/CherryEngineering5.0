package com.kj.cherryengineering20.localFiles;

import android.content.Context;

import com.kj.cherryengineering20.employees.Employee;

import java.io.FileOutputStream;
import java.io.IOException;

public class TestFile {

    public static void main(String[] args) {
        Employee eric = new Employee("eric");
        System.out.println(eric);
    }
}
