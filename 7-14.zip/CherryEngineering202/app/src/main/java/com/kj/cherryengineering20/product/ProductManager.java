package com.kj.cherryengineering20.product;

import android.graphics.Point;

import com.kj.cherryengineering20.CompletedCaseQuantityMenu.PointFiveWaterBottle;

import java.util.ArrayList;

public class ProductManager {

    private ArrayList<Product> products;
    PointFiveWaterBottle pointFiveMwb;

    public ProductManager() {
        this.products = new ArrayList<>();
        products.add(pointFiveMwb);
    }

    public void addProduct(Product p) {
        products.add(p);
    }

    public void removeProduct(Product p) {
        products.remove(p);
    }

    public ArrayList<String> getAllProductNames() {
        ArrayList<String> names = new ArrayList<>();
        for (Product p: this.products) {
            names.add(p.getName());
        }

        return names;
        //for spinner in CompletedCaseQuantityMenu
    }
}
