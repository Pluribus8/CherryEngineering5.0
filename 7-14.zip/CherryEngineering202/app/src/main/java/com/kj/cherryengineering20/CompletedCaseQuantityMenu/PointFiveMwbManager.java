package com.kj.cherryengineering20.CompletedCaseQuantityMenu;

public class PointFiveMwbManager {

    PointFiveWaterBottle pointFive;

    public PointFiveMwbManager() {
        pointFive = new PointFiveWaterBottle();
    }

    public void subtractCases(int numberOfCases) {

    }
}
