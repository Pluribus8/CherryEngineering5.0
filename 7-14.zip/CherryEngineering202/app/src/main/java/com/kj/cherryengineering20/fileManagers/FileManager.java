package com.kj.cherryengineering20.fileManagers;

import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLOutput;
import java.util.HashMap;

public class FileManager extends AppCompatActivity {

    private static final String FILE_NAME = "inventory.txt";

    public FileManager(String fileName) {
        //FILE_NAME = fileName;
    }

    public HashMap<String, Double> getFileAsHashmap() {
        FileInputStream fis = null;
        HashMap<String, Double> map = new HashMap<>();

        try {
            fis = openFileInput(FILE_NAME);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            String text;

            while ((text = br.readLine()) != null) {
                String[] itemLine = text.split(",");
                for (int i = 0; i < itemLine.length; i++) {
                    String[] item = itemLine[i].split("=");
                    item[0] = item[0].replaceAll("[\\[\\](){}]", "");
                    item[1] = item[1].replaceAll("[\\[\\](){}]", "");
                    String itemName = item[0];
                    double quantity = Double.parseDouble(item[1]);
                    map.put(itemName, quantity);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return map;
    }

    public void saveNewValues(HashMap<String, Double> map) {
        String content = map.toString();
        try (FileOutputStream fos = openFileOutput(FILE_NAME, MODE_PRIVATE)) {
            fos.write(content.getBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Toast.makeText(this, "Saved to " + getFilesDir() + "/inventory.txt", Toast.LENGTH_LONG).show();
    }
}
