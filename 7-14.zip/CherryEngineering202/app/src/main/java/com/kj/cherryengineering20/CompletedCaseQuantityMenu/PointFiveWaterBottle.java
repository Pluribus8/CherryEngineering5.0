package com.kj.cherryengineering20.CompletedCaseQuantityMenu;

import com.kj.cherryengineering20.product.Product;

public class PointFiveWaterBottle extends Product {

    private final double mwbTube;
    private final double mwbSlider;
    private final int screws;
    private final int caps;
    private final int bottles;
    private final int cross;
    private final int oRing;
    private final int endCap;
    private final double payrollPricePerCase;

    public PointFiveWaterBottle() {
        mwbTube = 0.1;
        mwbSlider = 0.007;
        screws = 1;
        caps = 1;
        bottles = 1;
        cross = 1;
        oRing = 1;
        endCap = 1;
        payrollPricePerCase = 41;
    }

    public double getMwbTube() {
        return mwbTube;
    }

    public double getMwbSlider() {
        return mwbSlider;
    }

    public int getScrews() {
        return screws;
    }

    public int getCaps() {
        return caps;
    }

    public int getBottles() {
        return bottles;
    }

    public int getCross() {
        return cross;
    }

    public int getoRing() {
        return oRing;
    }

    public int getEndCap() {
        return endCap;
    }
    public double getPayrollPricePerCase() {
        return payrollPricePerCase;
    }
}
