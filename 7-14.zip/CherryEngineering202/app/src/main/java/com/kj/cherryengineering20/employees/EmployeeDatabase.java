package com.kj.cherryengineering20.employees;

import static android.content.Context.MODE_PRIVATE;
import static android.os.ParcelFileDescriptor.MODE_APPEND;

import android.content.Context;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.kj.cherryengineering20.payroll.PayrollMenu;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EmployeeDatabase {

    private Context mContext;
    private String FILE_NAME = "employees.txt";

    public EmployeeDatabase(Context context) {
        mContext = context;
    }

    public Employee getEmployee(String name) {
        List<Employee> employees = getEmployees();
        for (Employee e: employees) {
            if (e.getName().equalsIgnoreCase(name)) {
                return e;
            }
        }
        return null;
    }

    public List<Employee> getEmployees() {
        List<Employee> employees = new ArrayList<>();
        File file = new File(mContext.getFilesDir(), FILE_NAME);

        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        try {
            FileInputStream fis = mContext.openFileInput("employees.txt");
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            String line;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                employees.add(new Employee(parts[0], Double.parseDouble(parts[1])));
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        return employees;
    }

    public List<String> getEmployeeNames() {
        List<Employee> employees = getEmployees();
        List<String> names = new ArrayList<>();

        for (Employee e: employees) {
            names.add(e.getName());
        }

        return names;
    }

    public String getEmployeeCurrentPayroll(String name) {
        try {
            FileInputStream fis = mContext.openFileInput(name + "Payroll.txt");
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder builder = new StringBuilder();
            String line;

            if (br.readLine() == null) {
                builder.append("\n\n\t\tNo completed cases. \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\t\tGet back to work.");
            } else {
                while ((line = br.readLine()) != null) {
                    builder.append(line + "\n");
                }
            }

            return builder.toString();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void moveCurrentToHistory(String name) {
        String toMove = getEmployeeCurrentPayroll(name);
        String fileName = name + "PayrollHistory.txt";
        File file = new File(mContext.getFilesDir(), fileName);

        try {
            FileOutputStream fos = mContext.openFileOutput(fileName, mContext.MODE_APPEND);
            fos.write(toMove.getBytes());
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        clearCurrentPayroll(name);
    }

    public void clearCurrentPayroll(String name) {
        File file = new File(mContext.getFilesDir(), name + "Payroll.txt");
        file.delete();
    }

    public void createEmployeePayrollFiles(String name) {
        File file = new File(mContext.getFilesDir(), name + "Payroll.txt");
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        File historyFile = new File(mContext.getFilesDir(), name + "PayrollHistory.txt");
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
