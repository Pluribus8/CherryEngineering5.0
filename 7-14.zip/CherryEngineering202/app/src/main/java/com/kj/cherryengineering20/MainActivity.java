package com.kj.cherryengineering20;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.kj.cherryengineering20.completedCaseActivity.CompletedCaseActivityMenu;
import com.kj.cherryengineering20.payroll.PayrollMenu;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView currentActivitiy = findViewById(R.id.currentActivity);
        currentActivitiy.setText(getLocalClassName());

        Button button1 = (Button) findViewById(R.id.buildButton);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCompletedCaseActivity();
            }
        });

        Button viewInventory = (Button) findViewById(R.id.view_inventory);
        viewInventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openInventoryViewer();
            }
        });

        Button openPayrollButton = (Button) findViewById(R.id.payroll);
        openPayrollButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openPayroll();
            }
        });
    }

    public void openCompletedCaseActivity() {
        Intent intent = new Intent(this, CompletedCaseActivityMenu.class);
        startActivity(intent);
    }

    public void openInventoryViewer() {
        startActivity(new Intent(this, InventoryViewer.class));
    }

    public void openPayroll() {
        startActivity(new Intent(this, PayrollMenu.class));
    }
}