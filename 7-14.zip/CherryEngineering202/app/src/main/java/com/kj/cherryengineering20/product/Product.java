package com.kj.cherryengineering20.product;

public class Product {

    private String name;
    private double pricePerCase;

    public Product() {

    }

    public Product(String name, double pricePerCase) {
        this.name = name;
        this.pricePerCase = pricePerCase;
    }

    public String getName() {
        return this.name;
    }

    public double getPricePerCase() {
        return this.pricePerCase;
    }

    public String toString() {
        return this.name;
    }
}