package com.kj.cherryengineering20.payroll;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.kj.cherryengineering20.R;

public class PayrollHistory extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payroll_history);
    }
}